from pathlib import Path
import argparse
import csv
import json
import os
import shlex
import subprocess
import sys


ROOT = Path(__file__).resolve().parent


def files_for(row):
    panel = row["panel"]
    if panel == "q2_confirmatory":
        return ROOT / "reproducibility/source_snapshot_q2_confirmatory", ROOT / "results/confirmatory/provenance.json"
    if panel == "q2_postconfirmatory_organsmnist_no_hflip":
        return ROOT / "reproducibility/source_snapshot_organsmnist_no_hflip", ROOT / "results/organsmnist_no_hflip/provenance.json"
    if panel != "q2_postconfirmatory_imagenet100":
        raise ValueError("Use research_revision/training/reproduce.py for the 960 revision recipes.")
    key = (row["model"], row["activation"], int(row["seed"]))
    matches = []
    for path in (ROOT / "imagenet100/records").rglob("done.json"):
        record = json.loads(path.read_bytes())
        if (record["model"], record["activation"], record["seed"]) == key:
            matches.append(record["experiment_id"])
    if len(matches) != 1:
        raise ValueError(f"Expected one historical ImageNet record for {key}, found {len(matches)}")
    identities = json.loads((ROOT / "imagenet100/provenance/module_fingerprints.json").read_bytes())
    return ROOT / "imagenet100" / identities[matches[0]]["directory"], ROOT / "imagenet100/provenance" / (matches[0] + ".json")


def command_for(row, data_dir, output_dir):
    tree, record = files_for(row)
    canonical = json.loads(record.read_bytes())["canonical_config"]
    cmd = [sys.executable, str(tree / "train_benchmark.py"), "--datasets", row["dataset"], "--models", row["model"], "--activations", row["activation"], "--seeds", row["seed"]]
    seeds = json.loads((ROOT / "protocol_q2_confirmatory.json").read_bytes())["seeds"]
    cmd.extend(["--seed_order", *map(str, seeds), "--lgts_alphas", "0.40", "--data_dir", str(Path(data_dir).resolve()), "--output_dir", str(Path(output_dir).resolve() / ("run_" + row["run_id"]))])
    for key, value in canonical.items():
        if isinstance(value, bool):
            if value:
                cmd.append("--" + key)
        else:
            cmd.extend(["--" + key, str(value)])
    return cmd


def main():
    parser = argparse.ArgumentParser(description="Reproduce one of the 375 historical fits from its archived settings.")
    parser.add_argument("run_id")
    parser.add_argument("--data-dir", default="data")
    parser.add_argument("--output-dir", default="reproduced")
    action = parser.add_mutually_exclusive_group()
    action.add_argument("--execute", action="store_true", help="Start the selected training run.")
    action.add_argument("--dry-run", action="store_true", help="Run the historical trainer's argument and design checks.")
    args = parser.parse_args()
    with (ROOT / "research_revision/results/run_settings.csv").open(encoding="utf-8-sig", newline="") as handle:
        row = next((r for r in csv.DictReader(handle) if r["run_id"] == args.run_id), None)
    if row is None:
        parser.error(f"Unknown run ID {args.run_id}")
    try:
        cmd = command_for(row, args.data_dir, args.output_dir)
    except ValueError as exc:
        parser.error(str(exc))
    if args.dry_run:
        cmd.append("--dry_run")
    print(subprocess.list2cmdline(cmd) if os.name == "nt" else shlex.join(cmd), flush=True)
    if args.execute or args.dry_run:
        subprocess.run(cmd, check=True)


if __name__ == "__main__":
    main()

