from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import t


MODELS = ["ResNet18", "MobileNetV2", "EfficientNetV2S"]
ACTIVATIONS = ["LGTS-f4-Alpha", "LGTS-f2-Slope", "ACON-C", "GELU", "Native"]
SEEDS = [936137, 529212, 448132, 942529, 110107]
PRIMARY = "LGTS-f4-Alpha"
KEYS = ["model", "activation", "seed"]
EXPERIMENT_PROVENANCE = {
    "exp_1290eceb1a58a8a1": "original_implementation",
    "exp_120723c43f1a2d73": "documentation_only_equivalent_implementation",
    "exp_0d203a9e72a528b9": "numerical_evaluation_repair_20260915",
}
RUN_RECORD_PATTERN = "*/*/*/*/*/*/full_train/done.json"
INFERENCE_METRICS = (
    "inference_ms_per_image", "throughput_images_sec", "peak_inference_gpu_memory_mb",
)
METRICS = [
    "test_f1_macro",
    "test_accuracy",
    "test_top5_accuracy",
    "test_balanced_accuracy",
    "test_mcc",
    "test_roc_auc_macro_ovr",
    "test_pr_auc_macro",
    "test_nll",
    "test_brier_score",
    "test_ece_15",
    "mean_epoch_time_sec",
    "train_time_sec",
    "inference_ms_per_image",
    "throughput_images_sec",
    "peak_training_gpu_memory_mb",
    "peak_inference_gpu_memory_mb",
    "total_parameters",
    "trainable_parameters",
    "lgts_alpha",
    "lgts_alpha_layer_sd",
    "lgts_alpha_layer_min",
    "lgts_alpha_layer_max",
    "lgts_alpha_near_lower_fraction",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Analyze the post-confirmatory ImageNet-100 extension")
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--expected-runs", type=int, default=75)
    return parser.parse_args()


def load_runs(root: Path) -> pd.DataFrame:
    rows: list[dict] = []
    for experiment_id, implementation in EXPERIMENT_PROVENANCE.items():
        for path in (root / experiment_id).glob(RUN_RECORD_PATTERN):
            row = json.loads(path.read_text(encoding="utf-8"))
            if row.get("dataset") != "imagenet100":
                continue
            if row.get("model") not in MODELS or row.get("activation") not in ACTIVATIONS:
                continue
            if int(row.get("seed", -1)) not in SEEDS:
                continue
            if row.get("protocol") != "full_train":
                continue
            if row.get("experiment_id") != experiment_id.removeprefix("exp_"):
                raise RuntimeError(f"Experiment identity does not match its source directory: {path}")
            row["source_experiment_directory"] = experiment_id
            row["implementation_lineage"] = implementation
            row.setdefault("evaluation_precision_used", "legacy_unrecorded")
            row["done_json"] = str(path.resolve())
            rows.append(row)
    frame = pd.DataFrame(rows)
    if frame.empty:
        raise RuntimeError(f"No matching ImageNet-100 completion records under {root}")
    if frame.duplicated(KEYS).any():
        dup = frame.loc[frame.duplicated(KEYS, keep=False), KEYS + ["done_json"]]
        raise RuntimeError(f"Duplicate completed keys:\n{dup.to_string(index=False)}")
    return frame


def expected_keys() -> set[tuple[str, str, int]]:
    return {(model, activation, seed) for model in MODELS for activation in ACTIVATIONS for seed in SEEDS}


def mean_sd_summary(frame: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict] = []
    for (model, activation), block in frame.groupby(["model", "activation"], sort=False):
        item: dict[str, object] = {"model": model, "activation": activation, "n_seeds": len(block)}
        precisions = sorted(block["evaluation_precision_used"].fillna("legacy_unrecorded").unique())
        item["evaluation_precisions"] = "|".join(precisions)
        item["inference_timing_status"] = (
            "mixed_precision_not_pooled" if len(precisions) > 1 else "single_recorded_precision"
            if precisions != ["legacy_unrecorded"] else "legacy_precision_unrecorded"
        )
        for metric in METRICS:
            if metric in INFERENCE_METRICS and len(precisions) > 1:
                continue
            if metric not in block.columns:
                continue
            values = pd.to_numeric(block[metric], errors="coerce").dropna()
            if values.empty:
                continue
            item[f"{metric}_mean"] = float(values.mean())
            item[f"{metric}_sd"] = float(values.std(ddof=1)) if len(values) > 1 else math.nan
        rows.append(item)
    result = pd.DataFrame(rows)
    model_order = {name: i for i, name in enumerate(MODELS)}
    activation_order = {name: i for i, name in enumerate(ACTIVATIONS)}
    result["_m"] = result["model"].map(model_order)
    result["_a"] = result["activation"].map(activation_order)
    return result.sort_values(["_m", "_a"]).drop(columns=["_m", "_a"]).reset_index(drop=True)


def inference_summary_by_precision(frame: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for keys, block in frame.groupby(["model", "activation", "evaluation_precision_used"], dropna=False, sort=False):
        item = dict(zip(["model", "activation", "evaluation_precision_used"], keys))
        item["n_seeds"] = len(block)
        for metric in INFERENCE_METRICS:
            if metric not in block:
                continue
            values = pd.to_numeric(block[metric], errors="coerce").dropna()
            if not values.empty:
                item[f"{metric}_mean"] = float(values.mean())
                item[f"{metric}_sd"] = float(values.std(ddof=1)) if len(values) > 1 else math.nan
        rows.append(item)
    return pd.DataFrame(rows)


def paired_summary(frame: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    details: list[pd.DataFrame] = []
    summaries: list[dict] = []
    paired_metrics = ["test_f1_macro", "test_accuracy", "test_top5_accuracy"]
    for model in MODELS:
        primary = frame[(frame.model == model) & (frame.activation == PRIMARY)][["seed"] + paired_metrics]
        for comparator in ACTIVATIONS:
            if comparator == PRIMARY:
                continue
            control = frame[(frame.model == model) & (frame.activation == comparator)][["seed"] + paired_metrics]
            paired = primary.merge(control, on="seed", validate="one_to_one", suffixes=("_lgts", "_comparator"))
            if len(paired) != len(SEEDS):
                raise RuntimeError(f"Expected five paired seeds for {model} vs {comparator}, found {len(paired)}")
            paired.insert(0, "model", model)
            paired.insert(1, "comparator", comparator)
            for metric in paired_metrics:
                paired[f"delta_{metric}"] = paired[f"{metric}_lgts"] - paired[f"{metric}_comparator"]
            details.append(paired)

            item: dict[str, object] = {"model": model, "comparator": comparator, "n_pairs": len(paired)}
            for metric in paired_metrics:
                delta = paired[f"delta_{metric}"].to_numpy(float)
                sd = float(delta.std(ddof=1))
                margin = float(t.ppf(0.975, len(delta) - 1) * sd / math.sqrt(len(delta)))
                item[f"delta_{metric}_mean"] = float(delta.mean())
                item[f"delta_{metric}_sd"] = sd
                item[f"delta_{metric}_ci95_low"] = float(delta.mean() - margin)
                item[f"delta_{metric}_ci95_high"] = float(delta.mean() + margin)
            f1_delta = paired["delta_test_f1_macro"].to_numpy(float)
            item["f1_wins"] = int((f1_delta > 0).sum())
            item["f1_ties"] = int((f1_delta == 0).sum())
            item["f1_losses"] = int((f1_delta < 0).sum())
            summaries.append(item)
    return pd.concat(details, ignore_index=True), pd.DataFrame(summaries)


def plot_results(summary: pd.DataFrame, root: Path) -> None:
    colors = {
        "LGTS-f4-Alpha": "#D55E00",
        "LGTS-f2-Slope": "#E69F00",
        "ACON-C": "#0072B2",
        "GELU": "#009E73",
        "Native": "#777777",
    }
    fig, axes = plt.subplots(1, 2, figsize=(11.0, 4.0))
    x = np.arange(len(MODELS), dtype=float)
    offsets = np.linspace(-0.28, 0.28, len(ACTIVATIONS))
    for offset, activation in zip(offsets, ACTIVATIONS):
        block = summary[summary.activation == activation].set_index("model").loc[MODELS]
        for ax, metric, title in [
            (axes[0], "test_f1_macro", "Macro-F1"),
            (axes[1], "test_accuracy", "Top-1 accuracy"),
        ]:
            mean = block[f"{metric}_mean"].to_numpy(float)
            sd = block[f"{metric}_sd"].to_numpy(float)
            ax.errorbar(
                x + offset,
                mean,
                yerr=sd,
                marker="o",
                linestyle="none",
                capsize=2.5,
                color=colors[activation],
                label=activation,
            )
            ax.set_title(title)
    for ax in axes:
        ax.set_xticks(x)
        ax.set_xticklabels(["ResNet18", "MobileNetV2", "EfficientNetV2-S"])
        ax.set_ylim(0, 1)
        ax.grid(axis="y", alpha=0.2)
    axes[0].set_ylabel("Mean ± sample SD across five paired seeds")
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="upper center", ncol=5, frameon=False, bbox_to_anchor=(0.5, 1.03))
    fig.suptitle("Post-confirmatory ImageNet-100 extension", y=1.12)
    fig.tight_layout()
    fig.savefig(root / "imagenet100_performance.png", dpi=300, bbox_inches="tight")
    fig.savefig(root / "imagenet100_performance.svg", bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    args = parse_args()
    frame = load_runs(args.root)
    expected = expected_keys()
    actual = set(map(tuple, frame[KEYS].itertuples(index=False, name=None)))
    if len(frame) != args.expected_runs or actual != expected:
        raise RuntimeError(
            f"ImageNet-100 integrity failure: expected={args.expected_runs}, found={len(frame)}, "
            f"missing={sorted(expected - actual)}, unexpected={sorted(actual - expected)}"
        )
    if not (pd.to_numeric(frame["epochs_run"], errors="coerce") == 100).all():
        raise RuntimeError("Every completed run must contain exactly 100 epochs")
    if not (pd.to_numeric(frame["image_size"], errors="coerce") == 160).all():
        raise RuntimeError("Every completed run must use 160 px input")
    if not (pd.to_numeric(frame["batch_size"], errors="coerce") == 64).all():
        raise RuntimeError("Every completed run must use batch size 64")

    args.root.mkdir(parents=True, exist_ok=True)
    frame.to_csv(args.root / "imagenet100_run_results.csv", index=False)
    summary = mean_sd_summary(frame)
    summary.to_csv(args.root / "imagenet100_summary_by_condition.csv", index=False)
    inference_summary_by_precision(frame).to_csv(
        args.root / "imagenet100_inference_by_precision.csv", index=False,
    )
    paired_runs, paired = paired_summary(frame)
    paired_runs.to_csv(args.root / "imagenet100_paired_seed_results.csv", index=False)
    paired.to_csv(args.root / "imagenet100_paired_summary.csv", index=False)
    plot_results(summary, args.root)

    integrity = {
        "status": "complete",
        "role": "post-confirmatory ImageNet-100 generalization extension",
        "expected_runs": args.expected_runs,
        "completed_runs": len(frame),
        "models": MODELS,
        "activations": ACTIVATIONS,
        "seeds": SEEDS,
        "protocol": "full_train",
        "image_size": 160,
        "batch_size": 64,
        "primary_confirmatory_statistics_changed": False,
        "implementation_provenance": [
            {"experiment_id": experiment_id, "implementation_lineage": implementation,
             "completed_runs": int((frame["source_experiment_directory"] == experiment_id).sum())}
            for experiment_id, implementation in EXPERIMENT_PROVENANCE.items()
        ],
        "evaluation_precision_counts": frame["evaluation_precision_used"].value_counts().to_dict(),
        "numerical_repair_is_code_equivalent": False,
        "numerical_repair_provenance_document": "NUMERICAL_REPAIR_20260915.md",
        "inference_reporting_note": (
            "Inference timings and peak memory depend on evaluation precision. Mixed-precision "
            "conditions are not pooled for these metrics; see imagenet100_inference_by_precision.csv. "
            "Legacy completion records lacking precision metadata are labelled legacy_unrecorded."
        ),
    }
    (args.root / "imagenet100_extension_integrity.json").write_text(
        json.dumps(integrity, indent=2), encoding="utf-8"
    )
    print(f"ImageNet-100 extension analysis complete: {len(frame)} runs")


if __name__ == "__main__":
    main()
