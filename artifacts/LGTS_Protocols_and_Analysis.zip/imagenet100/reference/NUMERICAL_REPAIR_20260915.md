| Experiment ID | Evaluation implementation | Completed runs | Recorded precision |
|---|---|---:|---|
| 1290eceb1a58a8a1 | Original | 2 | Unrecorded |
| 120723c43f1a2d73 | Original, class docstring changed | 40 | Unrecorded |
| 0d203a9e72a528b9 | Evaluation repair, 2026-09-15 | 33 | AMP: 27, FP32: 6 |
