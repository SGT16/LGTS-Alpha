Dataset | Provider or source | Study resolution | Access or attribution
---|---|---|---
CIFAR-100 | torchvision.datasets.CIFAR100 | 32 x 32 | Original CIFAR terms; https://www.cs.toronto.edu/~kriz/cifar.html
DermaMNIST | MedMNIST v2, dermamnist_64.npz | 64 x 64 | CC BY-NC 4.0; Yang et al., https://doi.org/10.1038/s41597-022-01721-8
OrganSMNIST | MedMNIST v2, organsmnist_64.npz | 64 x 64 | CC BY 4.0; Yang et al., https://doi.org/10.1038/s41597-022-01721-8
ImageNet-100 | https://huggingface.co/datasets/clane9/imagenet-100 | 160 x 160 | CMC subset; pinned revision 0519dc2f402a3a18c6e57f7913db059215eee25b; original ImageNet access terms
